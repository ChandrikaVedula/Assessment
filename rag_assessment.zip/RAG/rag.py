import os
import base64
import docx
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
import openai

OPENAI_KEY = "FhEmArJdZY4pBQzNTciGQsvFGex6E0VBrd0n13Ig7l50lvIzAMKEJQQJ99BIACHYHv6XJ3w3AAAAACOGaTZO"
OPENAI_ENDPOINT = "https://chand-mfgogert-eastus2.openai.azure.com/"
GPT_DEPLOYMENT = "gpt-4o-mini"

openai.api_type = "azure"
openai.api_version = "2025-01-01-preview"
openai.api_key = OPENAI_KEY
openai.azure_endpoint = OPENAI_ENDPOINT

SEARCH_ENDPOINT = "https://policysearch.search.windows.net"
SEARCH_KEY = "MXGCn8nK92SUXItAGz7sH6jmTR7BQ8gubmbrD28eDFAzSeDqVrIZ"
INDEX_NAME = "finalassessment"

search_client = SearchClient(
    endpoint=SEARCH_ENDPOINT,
    index_name=INDEX_NAME,
    credential=AzureKeyCredential(SEARCH_KEY)
)

def safe_key(filename, chunk_num=None):
    key = f"{filename}_{chunk_num}" if chunk_num is not None else filename
    key_bytes = base64.urlsafe_b64encode(key.encode("utf-8"))
    return key_bytes.decode("utf-8").rstrip("=")

LOCAL_FOLDER = r"C:\Users\91807\OneDrive\Desktop\RAG\rag_docs"
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50

def chunk_text(text, size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    chunks = []
    start = 0
    while start < len(text):
        end = start + size
        chunk = text[start:end]
        chunks.append(chunk)
        start += size - overlap
    return chunks

def load_docx_files(folder):
    if not os.path.exists(folder):
        raise FileNotFoundError(f"Folder '{folder}' not found!")
    docs = []
    for filename in os.listdir(folder):
        if filename.endswith(".docx") and not filename.startswith("~$"):
            path = os.path.join(folder, filename)
            doc = docx.Document(path)
            full_text = "\n".join([p.text for p in doc.paragraphs])
            text_chunks = chunk_text(full_text)
            for idx, chunk in enumerate(text_chunks):
                docs.append({
                    "id": safe_key(filename, idx),
                    "content": chunk
                })
    return docs

def upload_docs_to_search(docs):
    if not docs:
        print("No documents to upload.")
        return
    clean_docs = [{"id": d["id"], "content": d["content"]} for d in docs]
    try:
        result = search_client.upload_documents(documents=clean_docs)
        print(f"Uploaded {len(result)} document chunks to Azure Search.")
    except Exception as e:
        print("Upload failed:", e)

def get_top_matches(query, top_k=3):
    results = search_client.search(search_text=query, top=top_k)
    matches = []
    for r in results:
        matches.append((r.get("content"), r.get("id")))
    return matches

def generate_answer_with_context(question, top_matches):
    if not top_matches:
        return "I couldn't find relevant information in the documents, but according to my knowledge..."
    context_text = "\n\n".join([f"{i+1}. {para}" for i, (para, _) in enumerate(top_matches)])
    prompt = f"""
You are an HR assistant. Use the following policy documents to answer the question.
Do not make up answers that are not in the documents.

Policies:
{context_text}

Question: {question}

Answer:
"""
    response = openai.chat.completions.create(
        model=GPT_DEPLOYMENT,
        messages=[
            {"role": "system", "content": "You are a helpful HR assistant."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=400,
        temperature=0
    )
    return response.choices[0].message.content.strip()

def main():
    print("Loading and chunking .docx documents...")
    docs = load_docx_files(LOCAL_FOLDER)
    print(f"Loaded {len(docs)} document chunks...")

    print("Uploading chunks to Azure Search...")
    upload_docs_to_search(docs)

    print("\nRAG system is ready! Ask your questions (type 'exit' to quit).")

    while True:
        user_query = input("\nYour question: ")
        if user_query.lower() == "exit":
            break
        top_matches = get_top_matches(user_query, top_k=3)
        answer = generate_answer_with_context(user_query, top_matches)
        print("\nAnswer:")
        print(answer)
        print("\nSources:")
        for i, (_, source) in enumerate(top_matches, 1):
            print(f"{i}. {source}")

if __name__ == "__main__":
    main()
